﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLBH_MVC.Models
{
    public class SessionCartStatus
    {
        public int Total { get; set; }
    }
}