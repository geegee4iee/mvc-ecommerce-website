﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLBH_MVC.Models
{
    public class AdminManufacturerModel
    {
        public int MaId { get; set; }
        public string MaName { get; set; }
    }
}