﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLBH_MVC.Models
{
    public class AdminCategoryModel
    {
        public int CatId { get; set; }
        public string CatName { get; set; }
    }
}